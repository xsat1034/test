// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:aniwavex/app.dart';
import 'package:aniwavex/config/app_config.dart';
import 'package:aniwavex/services/storage_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Hive
  await Hive.initFlutter();
  await Hive.openBox('settings');
  await Hive.openBox('cache');
  
  // Initialize Secure Storage
  const secureStorage = FlutterSecureStorage();
  await StorageService.init(secureStorage);
  
  // Load configuration
  await AppConfig.instance.loadConfig();
  
  runApp(
    const ProviderScope(
      child: AniWaveXApp(),
    ),
  );
}