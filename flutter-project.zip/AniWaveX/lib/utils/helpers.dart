// lib/utils/helpers.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Helpers {
  static String formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy').format(date);
  }

  static String formatTime(DateTime date) {
    return DateFormat('HH:mm').format(date);
  }

  static String formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);
    
    if (hours > 0) {
      return '${hours}h ${minutes}m';
    } else if (minutes > 0) {
      return '${minutes}m ${seconds}s';
    } else {
      return '${seconds}s';
    }
  }

  static String formatNumber(int number) {
    if (number >= 1000000) {
      return '${(number / 1000000).toStringAsFixed(1)}M';
    } else if (number >= 1000) {
      return '${(number / 1000).toStringAsFixed(1)}K';
    }
    return number.toString();
  }

  static String truncateText(String text, int maxLength) {
    if (text.length <= maxLength) return text;
    return '${text.substring(0, maxLength)}...';
  }

  static Color getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'ongoing':
      case 'on going':
        return Colors.green;
      case 'completed':
        return Colors.blue;
      case 'hiatus':
        return Colors.orange;
      case 'dropped':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  static String getStatusText(String status) {
    switch (status.toLowerCase()) {
      case 'ongoing':
      case 'on going':
        return 'Ongoing';
      case 'completed':
        return 'Completed';
      case 'hiatus':
        return 'Hiatus';
      case 'dropped':
        return 'Dropped';
      default:
        return status;
    }
  }

  static String getEpisodeDisplay(int episode, int total) {
    if (total > 0) {
      return 'EP $episode / $total';
    }
    return 'EP $episode';
  }

  static double getProgressPercentage(int current, int total) {
    if (total <= 0) return 0;
    return current / total;
  }

  static String getTimeAgo(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 365) {
      return '${(difference.inDays / 365).floor()} years ago';
    } else if (difference.inDays > 30) {
      return '${(difference.inDays / 30).floor()} months ago';
    } else if (difference.inDays > 7) {
      return '${(difference.inDays / 7).floor()} weeks ago';
    } else if (difference.inDays > 0) {
      return '${difference.inDays} days ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours} hours ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes} minutes ago';
    } else {
      return 'Just now';
    }
  }

  static void showSnackBar(BuildContext context, String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  static Future<void> showLoadingDialog(BuildContext context) async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Loading...'),
          ],
        ),
      ),
    );
  }

  static Color getLevelColor(int level) {
    if (level <= 5) return Colors.green;
    if (level <= 10) return Colors.blue;
    if (level <= 20) return Colors.purple;
    if (level <= 30) return Colors.orange;
    if (level <= 40) return Colors.red;
    if (level <= 50) return Colors.pink;
    return Colors.amber;
  }

  static String getLevelTitle(int level) {
    if (level <= 5) return 'Bronze';
    if (level <= 10) return 'Silver';
    if (level <= 20) return 'Gold';
    if (level <= 30) return 'Platinum';
    if (level <= 40) return 'Diamond';
    if (level <= 50) return 'Master';
    return 'Legend';
  }
}