// lib/models/anime.dart
class Anime {
  final String title;
  final String link;
  final String imageUrl;
  final String episode;
  final String type;
  final String? date;
  final double? rating;
  final String? genres;
  final String? status;

  Anime({
    required this.title,
    required this.link,
    required this.imageUrl,
    required this.episode,
    required this.type,
    this.date,
    this.rating,
    this.genres,
    this.status,
  });

  factory Anime.fromJson(Map<String, dynamic> json) {
    return Anime(
      title: json['title'] ?? '',
      link: json['link'] ?? '',
      imageUrl: json['imageUrl'] ?? '',
      episode: json['episode'] ?? '?',
      type: json['type'] ?? 'TV',
      date: json['date'],
      rating: json['rating']?.toDouble(),
      genres: json['genres'],
      status: json['status'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'link': link,
      'imageUrl': imageUrl,
      'episode': episode,
      'type': type,
      'date': date,
      'rating': rating,
      'genres': genres,
      'status': status,
    };
  }
}

class AnimeDetail {
  final AnimeInfo info;
  final List<Episode> episodes;

  AnimeDetail({
    required this.info,
    required this.episodes,
  });

  factory AnimeDetail.fromJson(Map<String, dynamic> json) {
    final info = AnimeInfo.fromJson(json['animeInfo']);
    final episodes = (json['episodes'] as List)
        .map((e) => Episode.fromJson(e))
        .toList();
    return AnimeDetail(info: info, episodes: episodes);
  }
}

class AnimeInfo {
  final String title;
  final String japaneseTitle;
  final String imageUrl;
  final String score;
  final String type;
  final String status;
  final String totalEpisodes;
  final String studio;
  final String genres;
  final String releaseDate;
  final String duration;
  final String synopsis;
  final String producer;

  AnimeInfo({
    required this.title,
    required this.japaneseTitle,
    required this.imageUrl,
    required this.score,
    required this.type,
    required this.status,
    required this.totalEpisodes,
    required this.studio,
    required this.genres,
    required this.releaseDate,
    required this.duration,
    this.synopsis = '',
    this.producer = '',
  });

  factory AnimeInfo.fromJson(Map<String, dynamic> json) {
    return AnimeInfo(
      title: json['title'] ?? '',
      japaneseTitle: json['japaneseTitle'] ?? '',
      imageUrl: json['imageUrl'] ?? '',
      score: json['score'] ?? 'N/A',
      type: json['type'] ?? '-',
      status: json['status'] ?? '-',
      totalEpisodes: json['totalEpisodes'] ?? '?',
      studio: json['studio'] ?? '-',
      genres: json['genres'] ?? '-',
      releaseDate: json['releaseDate'] ?? '-',
      duration: json['duration'] ?? '-',
      synopsis: json['synopsis'] ?? '',
      producer: json['producer'] ?? '',
    );
  }
}

class Episode {
  final String title;
  final String link;
  final String date;

  Episode({
    required this.title,
    required this.link,
    this.date = '',
  });

  factory Episode.fromJson(Map<String, dynamic> json) {
    return Episode(
      title: json['title'] ?? '',
      link: json['link'] ?? '',
      date: json['date'] ?? '',
    );
  }
}

class StreamingData {
  final String animeTitle;
  final String episodeTitle;
  final String videoUrl;
  final String? nextEpisode;
  final String? prevEpisode;

  StreamingData({
    required this.animeTitle,
    required this.episodeTitle,
    required this.videoUrl,
    this.nextEpisode,
    this.prevEpisode,
  });

  factory StreamingData.fromJson(Map<String, dynamic> json) {
    return StreamingData(
      animeTitle: json['animeTitle'] ?? '',
      episodeTitle: json['episodeTitle'] ?? '',
      videoUrl: json['videoUrl'] ?? '',
      nextEpisode: json['nextEpisode'],
      prevEpisode: json['prevEpisode'],
    );
  }
}