// lib/models/user.dart
class User {
  final String id;
  final String username;
  final String displayName;
  final String email;
  final String? phone;
  final String? avatar;
  final DateTime createdAt;
  final DateTime lastLogin;
  final bool premium;
  final int coin;
  final int exp;
  final int level;
  final int episodeWatched;
  final int favoriteCount;

  User({
    required this.id,
    required this.username,
    required this.displayName,
    required this.email,
    this.phone,
    this.avatar,
    required this.createdAt,
    required this.lastLogin,
    this.premium = false,
    this.coin = 0,
    this.exp = 0,
    this.level = 1,
    this.episodeWatched = 0,
    this.favoriteCount = 0,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] ?? '',
      username: json['username'] ?? '',
      displayName: json['displayName'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'],
      avatar: json['avatar'],
      createdAt: DateTime.parse(json['createdAt'] ?? DateTime.now().toIso8601String()),
      lastLogin: DateTime.parse(json['lastLogin'] ?? DateTime.now().toIso8601String()),
      premium: json['premium'] ?? false,
      coin: json['coin'] ?? 0,
      exp: json['exp'] ?? 0,
      level: json['level'] ?? 1,
      episodeWatched: json['episodeWatched'] ?? 0,
      favoriteCount: json['favoriteCount'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'displayName': displayName,
      'email': email,
      'phone': phone,
      'avatar': avatar,
      'createdAt': createdAt.toIso8601String(),
      'lastLogin': lastLogin.toIso8601String(),
      'premium': premium,
      'coin': coin,
      'exp': exp,
      'level': level,
      'episodeWatched': episodeWatched,
      'favoriteCount': favoriteCount,
    };
  }

  User copyWith({
    String? username,
    String? displayName,
    String? email,
    String? phone,
    String? avatar,
    int? coin,
    int? exp,
    int? level,
    int? episodeWatched,
    bool? premium,
  }) {
    return User(
      id: id,
      username: username ?? this.username,
      displayName: displayName ?? this.displayName,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      avatar: avatar ?? this.avatar,
      createdAt: createdAt,
      lastLogin: lastLogin,
      premium: premium ?? this.premium,
      coin: coin ?? this.coin,
      exp: exp ?? this.exp,
      level: level ?? this.level,
      episodeWatched: episodeWatched ?? this.episodeWatched,
      favoriteCount: favoriteCount,
    );
  }
}

class UserStats {
  final int totalWatched;
  final int totalFavorites;
  final int currentLevel;
  final int currentExp;
  final int expToNextLevel;
  final int coins;

  UserStats({
    required this.totalWatched,
    required this.totalFavorites,
    required this.currentLevel,
    required this.currentExp,
    required this.expToNextLevel,
    required this.coins,
  });

  factory UserStats.fromUser(User user) {
    final expPerLevel = 1000;
    final currentExp = user.exp % expPerLevel;
    final expToNext = expPerLevel - currentExp;
    
    return UserStats(
      totalWatched: user.episodeWatched,
      totalFavorites: user.favoriteCount,
      currentLevel: user.level,
      currentExp: currentExp,
      expToNextLevel: expToNext,
      coins: user.coin,
    );
  }
}