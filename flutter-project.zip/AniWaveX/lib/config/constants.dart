// lib/config/constants.dart
import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'AniWaveX';
  static const String packageName = 'com.aniwavex.app';
  static const String version = '1.0.0';
  
  // Theme Colors
  static const Color primaryColor = Color(0xFF6C3CE1);
  static const Color secondaryColor = Color(0xFFE03C6C);
  static const Color accentColor = Color(0xFF3CE1D9);
  static const Color backgroundColor = Color(0xFF0D0D0D);
  static const Color surfaceColor = Color(0xFF1A1A1A);
  
  // Animation Durations
  static const Duration animationDuration = Duration(milliseconds: 300);
  static const Duration splashDuration = Duration(seconds: 3);
  
  // Cache
  static const int maxCacheAge = 7;
  static const int maxCacheItems = 100;
  
  // Pagination
  static const int defaultPageSize = 20;
  
  // Video
  static const double defaultPlaybackSpeed = 1.0;
  static const List<double> playbackSpeeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
  
  // Level System
  static const int expPerEpisode = 100;
  static const int episodesPerLevel = 10;
  static const int coinsPerEpisode = 5;
  
  // API Endpoints
  static const String endpointLogin = '/auth/login';
  static const String endpointRegister = '/auth/register';
  static const String endpointLogout = '/auth/logout';
  static const String endpointResetPassword = '/auth/reset-password';
  static const String endpointValidate = '/auth/validate';
  static const String endpointProfile = '/user/profile';
  static const String endpointOngoing = '/api/anime/ongoing';
  static const String endpointSearch = '/api/anime/search';
  static const String endpointDetail = '/api/anime/detail';
  static const String endpointWatch = '/api/anime/watch';
  static const String endpointTrending = '/api/anime/trending';
  static const String endpointLatest = '/api/anime/latest';
  static const String endpointFavorites = '/favorites';
  static const String endpointHistory = '/history';
  static const String endpointWatchProgress = '/watch-progress';
  static const String endpointSettings = '/settings';
  static const String endpointNotifications = '/notifications';
}