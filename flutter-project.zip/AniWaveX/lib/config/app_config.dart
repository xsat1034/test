// lib/config/app_config.dart
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class AppConfig {
  static final AppConfig _instance = AppConfig._internal();
  factory AppConfig() => _instance;
  AppConfig._internal();

  static AppConfig get instance => _instance;

  static const String CONFIG_URL = 
      'https://raw.githubusercontent.com/xsat1034/aniwavex/main/config.json';
      
  String mainServer = 'http://dua.daiyat.my.id:3007';
  String backupServer1 = 'http://backup1.aniwave.com:3000';
  String backupServer2 = 'http://backup2.aniwave.com:3000';
  bool maintenance = false;
  String appVersion = '1.0.0';
  String currentServer = '';
  bool isConfigLoaded = false;

  Future<void> loadConfig() async {
    try {
      final dio = Dio();
      final response = await dio.get(CONFIG_URL);
      
      if (response.statusCode == 200) {
        final data = response.data;
        mainServer = data['mainServer'] ?? mainServer;
        backupServer1 = data['backupServer1'] ?? backupServer1;
        backupServer2 = data['backupServer2'] ?? backupServer2;
        maintenance = data['maintenance'] ?? false;
        appVersion = data['version'] ?? appVersion;
        currentServer = mainServer;
        isConfigLoaded = true;
        debugPrint('✅ Config loaded: $currentServer');
      }
    } catch (e) {
      debugPrint('❌ Error loading config: $e');
      currentServer = mainServer;
      isConfigLoaded = true;
    }
  }

  Future<String> getBaseUrl() async {
    if (!isConfigLoaded) {
      await loadConfig();
    }
    
    // Try main server
    try {
      final dio = Dio();
      final response = await dio.head('$mainServer/health');
      if (response.statusCode == 200) {
        currentServer = mainServer;
        return mainServer;
      }
    } catch (e) {
      debugPrint('⚠️ Main server failed');
    }

    // Try backup 1
    if (backupServer1.isNotEmpty) {
      try {
        final dio = Dio();
        final response = await dio.head('$backupServer1/health');
        if (response.statusCode == 200) {
          currentServer = backupServer1;
          return backupServer1;
        }
      } catch (e) {
        debugPrint('⚠️ Backup 1 failed');
      }
    }

    // Try backup 2
    if (backupServer2.isNotEmpty) {
      try {
        final dio = Dio();
        final response = await dio.head('$backupServer2/health');
        if (response.statusCode == 200) {
          currentServer = backupServer2;
          return backupServer2;
        }
      } catch (e) {
        debugPrint('⚠️ Backup 2 failed');
      }
    }

    return mainServer;
  }
}