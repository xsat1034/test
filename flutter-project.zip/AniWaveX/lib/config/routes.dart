// lib/config/routes.dart (Switch dengan toString)
import 'package:flutter/material.dart';
import 'package:aniwavex/screens/auth/login_screen.dart';
import 'package:aniwavex/screens/auth/register_screen.dart';
import 'package:aniwavex/screens/home/home_screen.dart';
import 'package:aniwavex/screens/anime/detail_screen.dart';
import 'package:aniwavex/screens/player/player_screen.dart';
import 'package:aniwavex/screens/profile/profile_screen.dart';
import 'package:aniwavex/screens/settings/settings_screen.dart';
import 'package:aniwavex/screens/splash/splash_screen.dart';

class AppRoutes {
  static const String splash = '/splash';
  static const String login = '/login';
  static const String register = '/register';
  static const String home = '/home';
  static const String animeDetail = '/anime/detail';
  static const String player = '/player';
  static const String profile = '/profile';
  static const String settings = '/settings';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    // Gunakan switch dengan .toString() atau string literal
    switch (settings.name) {
      case '/splash':
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case '/login':
        return MaterialPageRoute(builder: (_) => const LoginScreen());
      case '/register':
        return MaterialPageRoute(builder: (_) => const RegisterScreen());
      case '/home':
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case '/anime/detail':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => AnimeDetailScreen(animeUrl: args['url']),
        );
      case '/player':
        final args = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => PlayerScreen(
            videoUrl: args['videoUrl'],
            animeTitle: args['animeTitle'],
            episodeTitle: args['episodeTitle'],
            episodeUrl: args['episodeUrl'] ?? '',
          ),
        );
      case '/profile':
        return MaterialPageRoute(builder: (_) => const ProfileScreen());
      case '/settings':
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => const Scaffold(
            body: Center(child: Text('Page not found')),
          ),
        );
    }
  }
}