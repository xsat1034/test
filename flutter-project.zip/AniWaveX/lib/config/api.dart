import 'package:dio/dio.dart';
import 'package:aniwavex/config/app_config.dart';
import 'package:aniwavex/services/storage_service.dart';

class ApiClient {
  static final Dio _dio = Dio();

  static bool _initialized = false;

  static Future<void> init() async {
    if (_initialized) return;

    final baseUrl = await AppConfig.instance.getBaseUrl();

    _dio.options = BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      sendTimeout: const Duration(seconds: 30),
      contentType: Headers.jsonContentType,
      responseType: ResponseType.json,
      headers: {
        'Accept': 'application/json',
      },
      validateStatus: (status) {
        return status != null && status < 500;
      },
    );

    _dio.interceptors.clear();

    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await StorageService.getToken();

          if (token != null && token.isNotEmpty) {
            options.headers['Authorization'] = 'Bearer $token';
          }

          handler.next(options);
        },
        onError: (error, handler) async {
          if (error.response?.statusCode == 401) {
            await StorageService.clearToken();
          }

          handler.next(error);
        },
      ),
    );

    _initialized = true;
  }

  static Future<Response> get(
    String path, {
    Map<String, dynamic>? queryParams,
  }) async {
    await init();

    return _dio.get(
      path,
      queryParameters: queryParams,
    );
  }

  static Future<Response> post(
    String path, {
    dynamic data,
  }) async {
    await init();

    return _dio.post(
      path,
      data: data,
    );
  }

  static Future<Response> put(
    String path, {
    dynamic data,
  }) async {
    await init();

    return _dio.put(
      path,
      data: data,
    );
  }

  static Future<Response> delete(String path) async {
    await init();

    return _dio.delete(path);
  }
}