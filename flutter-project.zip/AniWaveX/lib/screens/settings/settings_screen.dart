// lib/screens/settings/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:aniwavex/providers/theme_provider.dart';
import 'package:aniwavex/services/storage_service.dart';
import 'package:aniwavex/config/constants.dart';
import 'package:aniwavex/config/api.dart';
import 'package:aniwavex/utils/helpers.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  bool _notifications = true;
  bool _autoNext = true;
  bool _saveProgress = true;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    try {
      final response = await ApiClient.get(AppConstants.endpointSettings);
      if (response.statusCode == 200 && response.data['success']) {
        final settings = response.data['data'];
        setState(() {
          _notifications = settings['notifications'] ?? true;
          _autoNext = settings['autoNext'] ?? true;
          _saveProgress = settings['saveProgress'] ?? true;
        });
      }
    } catch (e) {
      // Load from local storage
      setState(() {
        _notifications = StorageService.getBool('notifications') ?? true;
        _autoNext = StorageService.getBool('auto_next') ?? true;
        _saveProgress = StorageService.getBool('save_progress') ?? true;
      });
    }
  }

  Future<void> _saveSetting(String key, dynamic value) async {
    try {
      await ApiClient.put(
        AppConstants.endpointSettings,
        data: {key: value},
      );
      StorageService.saveBool(key, value as bool);
    } catch (e) {
      StorageService.saveBool(key, value as bool);
    }
  }

  Future<void> _clearCache() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Cache'),
        content: const Text(
          'This will clear all cached images and data. Continue?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Clear'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      setState(() => _isLoading = true);
      await StorageService.clearCache();
      setState(() => _isLoading = false);
      
      Helpers.showSnackBar(
        context,
        'Cache cleared successfully',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: Colors.transparent,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Appearance
                _buildSection(
                  title: 'Appearance',
                  children: [
                    _buildThemeToggle(),
                  ],
                ),

                const SizedBox(height: 16),

                // Preferences
                _buildSection(
                  title: 'Preferences',
                  children: [
                    SwitchListTile(
                      title: const Text('Notifications'),
                      subtitle: const Text('Receive updates and notifications'),
                      value: _notifications,
                      onChanged: (value) {
                        setState(() => _notifications = value);
                        _saveSetting('notifications', value);
                      },
                      activeColor: AppConstants.primaryColor,
                      secondary: const Icon(Icons.notifications_outlined),
                    ),
                    const Divider(height: 1),
                    SwitchListTile(
                      title: const Text('Auto Next Episode'),
                      subtitle: const Text('Automatically play next episode'),
                      value: _autoNext,
                      onChanged: (value) {
                        setState(() => _autoNext = value);
                        _saveSetting('autoNext', value);
                      },
                      activeColor: AppConstants.primaryColor,
                      secondary: const Icon(Icons.skip_next_outlined),
                    ),
                    const Divider(height: 1),
                    SwitchListTile(
                      title: const Text('Save Progress'),
                      subtitle: const Text('Save watch progress automatically'),
                      value: _saveProgress,
                      onChanged: (value) {
                        setState(() => _saveProgress = value);
                        _saveSetting('saveProgress', value);
                      },
                      activeColor: AppConstants.primaryColor,
                      secondary: const Icon(Icons.save_outlined),
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // Data
                _buildSection(
                  title: 'Data',
                  children: [
                    ListTile(
                      leading: const Icon(Icons.delete_outline),
                      title: const Text('Clear Cache'),
                      subtitle: const Text('Clear cached images and data'),
                      onTap: _clearCache,
                      trailing: const Icon(Icons.chevron_right),
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // About
                _buildSection(
                  title: 'About',
                  children: [
                    ListTile(
                      leading: const Icon(Icons.info_outline),
                      title: const Text('About AniWaveX'),
                      subtitle: Text('Version ${AppConstants.version}'),
                      onTap: () {
                        showAboutDialog(
                          context: context,
                          applicationName: AppConstants.appName,
                          applicationVersion: AppConstants.version,
                          applicationIcon: const Icon(
                            Icons.play_circle_filled,
                            size: 48,
                            color: AppConstants.primaryColor,
                          ),
                          children: const [
                            Text('AniWaveX - Stream anime terbaik dengan kualitas tinggi.'),
                            SizedBox(height: 8),
                            Text('© 2024 AniWaveX. All rights reserved.'),
                          ],
                        );
                      },
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.privacy_tip_outlined),
                      title: const Text('Privacy Policy'),
                      onTap: () async {
                        final url = Uri.parse('https://aniwavex.com/privacy');
                        if (await canLaunchUrl(url)) {
                          await launchUrl(url);
                        }
                      },
                      trailing: const Icon(Icons.open_in_new, size: 18),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.gavel_outlined),
                      title: const Text('Terms of Service'),
                      onTap: () async {
                        final url = Uri.parse('https://aniwavex.com/terms');
                        if (await canLaunchUrl(url)) {
                          await launchUrl(url);
                        }
                      },
                      trailing: const Icon(Icons.open_in_new, size: 18),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.share_outlined),
                      title: const Text('Share App'),
                      onTap: () {
                        Share.share(
                          'Check out AniWaveX - The best anime streaming app! 🎬\nDownload now: https://aniwavex.com/download',
                          subject: 'AniWaveX',
                        );
                      },
                      trailing: const Icon(Icons.chevron_right),
                    ),
                  ],
                ),

                const SizedBox(height: 16),

                // Version
                Center(
                  child: Text(
                    'AniWaveX v${AppConstants.version}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade500,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
    );
  }

  Widget _buildSection({
    required String title,
    required List<Widget> children,
  }) {
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              title,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade600,
              ),
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildThemeToggle() {
    final themeMode = ref.watch(themeModeProvider);
    
    return ListTile(
      leading: const Icon(Icons.dark_mode_outlined),
      title: const Text('Theme'),
      subtitle: Text(
        themeMode == ThemeMode.system
            ? 'Follow system'
            : themeMode == ThemeMode.light
            ? 'Light mode'
            : 'Dark mode',
      ),
      trailing: DropdownButton<ThemeMode>(
        value: themeMode,
        underline: const SizedBox(),
        items: const [
          DropdownMenuItem(
            value: ThemeMode.system,
            child: Text('System'),
          ),
          DropdownMenuItem(
            value: ThemeMode.light,
            child: Text('Light'),
          ),
          DropdownMenuItem(
            value: ThemeMode.dark,
            child: Text('Dark'),
          ),
        ],
        onChanged: (value) {
          if (value != null) {
            ref.read(themeModeProvider.notifier).setThemeMode(value);
          }
        },
      ),
    );
  }
}