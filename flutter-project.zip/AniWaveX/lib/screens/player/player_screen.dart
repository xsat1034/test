// lib/screens/player/player_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:aniwavex/services/storage_service.dart';
import 'package:aniwavex/config/constants.dart';
import 'package:aniwavex/config/api.dart';
import 'package:aniwavex/utils/helpers.dart';

class PlayerScreen extends StatefulWidget {
  final String videoUrl;
  final String animeTitle;
  final String episodeTitle;
  final String episodeUrl;

  const PlayerScreen({
    super.key,
    required this.videoUrl,
    required this.animeTitle,
    required this.episodeTitle,
    required this.episodeUrl,
  });

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late VideoPlayerController _controller;
  bool _isLoading = true;
  bool _isPlaying = false;
  bool _isFullscreen = false;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;
  double _playbackSpeed = 1.0;
  bool _isControlsVisible = true;
  Timer? _controlsTimer;
  bool _isDragging = false;

  @override
  void initState() {
    super.initState();
    _initializePlayer();
    WakelockPlus.enable();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
      DeviceOrientation.portraitUp,
    ]);
  }

  Future<void> _initializePlayer() async {
    _controller = VideoPlayerController.networkUrl(
      Uri.parse(widget.videoUrl),
      videoPlayerOptions: VideoPlayerOptions(
        mixWithOthers: true,
      ),
    );

    try {
      await _controller.initialize();
      _controller.addListener(_updateState);
      
      final savedProgress = StorageService.getWatchProgress(
        widget.animeTitle,
        widget.episodeUrl,
      );
      
      if (savedProgress != null && savedProgress > 0) {
        final position = Duration(
          milliseconds: ((savedProgress / 100) * _controller.value.duration.inMilliseconds).toInt(),
        );
        await _controller.seekTo(position);
      }

      setState(() {
        _isLoading = false;
        _totalDuration = _controller.value.duration;
      });
      
      await _controller.play();
      setState(() => _isPlaying = true);
      
      _showControls();
    } catch (e) {
      setState(() => _isLoading = false);
      Helpers.showSnackBar(
        context,
        'Failed to load video: $e',
        isError: true,
      );
    }
  }

  void _updateState() {
    if (_controller.value.isPlaying != _isPlaying) {
      setState(() => _isPlaying = _controller.value.isPlaying);
    }
    if (!_isDragging && _controller.value.position != _currentPosition) {
      setState(() => _currentPosition = _controller.value.position);
    }
    if (_controller.value.duration != _totalDuration) {
      setState(() => _totalDuration = _controller.value.duration);
    }
    
    if (_currentPosition.inSeconds % 5 == 0 && _currentPosition.inSeconds > 0) {
      _saveProgress();
    }
  }

  void _saveProgress() {
    if (_totalDuration.inMilliseconds == 0) return;
    
    final progress = (_currentPosition.inMilliseconds / _totalDuration.inMilliseconds * 100).round();
    StorageService.saveWatchProgress(
      widget.animeTitle,
      widget.episodeUrl,
      progress,
    );
    
    ApiClient.post(
      AppConstants.endpointWatchProgress,
      data: {
        'animeId': widget.animeTitle,
        'episodeId': widget.episodeUrl,
        'progress': progress,
        'duration': _totalDuration.inSeconds,
      },
    ).catchError((e) {
      debugPrint('Failed to save progress: $e');
    });
  }

  void _showControls() {
    setState(() => _isControlsVisible = true);
    _controlsTimer?.cancel();
    _controlsTimer = Timer(const Duration(seconds: 3), () {
      if (_isPlaying) {
        setState(() => _isControlsVisible = false);
      }
    });
  }

  void _toggleControls() {
    if (_isControlsVisible) {
      setState(() => _isControlsVisible = false);
      _controlsTimer?.cancel();
    } else {
      _showControls();
    }
  }

  void _togglePlayPause() {
    if (_controller.value.isPlaying) {
      _controller.pause();
    } else {
      _controller.play();
      _showControls();
    }
  }

  void _toggleFullscreen() {
    setState(() {
      _isFullscreen = !_isFullscreen;
    });
    if (_isFullscreen) {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
    } else {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
  }

  void _skipForward() {
    final newPosition = _currentPosition + const Duration(seconds: 10);
    if (newPosition < _totalDuration) {
      _controller.seekTo(newPosition);
    }
  }

  void _skipBackward() {
    final newPosition = _currentPosition - const Duration(seconds: 10);
    if (newPosition > Duration.zero) {
      _controller.seekTo(newPosition);
    } else {
      _controller.seekTo(Duration.zero);
    }
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);
    if (duration.inHours > 0) {
      return '${duration.inHours}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
    }
    return '${minutes}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _saveProgress();
    _controller.removeListener(_updateState);
    _controller.dispose();
    _controlsTimer?.cancel();
    WakelockPlus.disable();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    color: Colors.white,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Loading video...',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            )
          : Stack(
              children: [
                Center(
                  child: AspectRatio(
                    aspectRatio: _controller.value.aspectRatio,
                    child: VideoPlayer(_controller),
                  ),
                ),
                Positioned.fill(
                  child: GestureDetector(
                    onTap: _toggleControls,
                    onDoubleTap: _togglePlayPause,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(_isControlsVisible ? 0.4 : 0),
                            Colors.transparent,
                            Colors.black.withOpacity(_isControlsVisible ? 0.4 : 0),
                          ],
                          stops: const [0.0, 0.3, 0.7],
                        ),
                      ),
                      child: AnimatedOpacity(
                        opacity: _isControlsVisible ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 300),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            IconButton(
                              icon: Icon(
                                _isPlaying ? Icons.pause_circle_outline : Icons.play_circle_outline,
                                size: 60,
                                color: Colors.white.withOpacity(0.8),
                              ),
                              onPressed: _togglePlayPause,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: AnimatedOpacity(
                    opacity: _isControlsVisible ? 1.0 : 0.0,
                    duration: const Duration(milliseconds: 300),
                    child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back),
                              color: Colors.white,
                              onPressed: () => Navigator.pop(context),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    widget.animeTitle,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    widget.episodeTitle,
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.7),
                                      fontSize: 12,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: Icon(
                                _isFullscreen ? Icons.fullscreen_exit : Icons.fullscreen,
                              ),
                              color: Colors.white,
                              onPressed: _toggleFullscreen,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: AnimatedOpacity(
                    opacity: _isControlsVisible ? 1.0 : 0.0,
                    duration: const Duration(milliseconds: 300),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      color: Colors.black.withOpacity(0.8),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text(
                                _formatDuration(_currentPosition),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                              Expanded(
                                child: SliderTheme(
                                  data: SliderTheme.of(context).copyWith(
                                    trackHeight: 3,
                                    thumbShape: const RoundSliderThumbShape(
                                      enabledThumbRadius: 6,
                                    ),
                                    overlayShape: const RoundSliderOverlayShape(
                                      overlayRadius: 10,
                                    ),
                                    activeTrackColor: const Color(0xFF6C3CE1),
                                    inactiveTrackColor: Colors.grey.withOpacity(0.3),
                                    thumbColor: const Color(0xFF6C3CE1),
                                    overlayColor: const Color(0xFF6C3CE1).withOpacity(0.2),
                                  ),
                                  child: Slider(
                                    value: _currentPosition.inMilliseconds.toDouble(),
                                    min: 0,
                                    max: _totalDuration.inMilliseconds.toDouble(),
                                    onChanged: (value) {
                                      setState(() {
                                        _isDragging = true;
                                        _currentPosition = Duration(milliseconds: value.toInt());
                                      });
                                    },
                                    onChangeEnd: (value) {
                                      final position = Duration(milliseconds: value.toInt());
                                      _controller.seekTo(position);
                                      setState(() => _isDragging = false);
                                      _showControls();
                                    },
                                  ),
                                ),
                              ),
                              Text(
                                _formatDuration(_totalDuration),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.replay_10),
                                color: Colors.white,
                                onPressed: _skipBackward,
                              ),
                              IconButton(
                                icon: Icon(
                                  _isPlaying ? Icons.pause : Icons.play_arrow,
                                  size: 36,
                                ),
                                color: Colors.white,
                                onPressed: _togglePlayPause,
                              ),
                              IconButton(
                                icon: const Icon(Icons.forward_10),
                                color: Colors.white,
                                onPressed: _skipForward,
                              ),
                              PopupMenuButton<double>(
                                icon: const Icon(
                                  Icons.speed,
                                  color: Colors.white,
                                ),
                                onSelected: (speed) {
                                  setState(() => _playbackSpeed = speed);
                                  _controller.setPlaybackSpeed(speed);
                                },
                                itemBuilder: (context) => AppConstants.playbackSpeeds.map((speed) {
                                  return PopupMenuItem(
                                    value: speed,
                                    child: Row(
                                      children: [
                                        Text('${speed}x'),
                                        if (speed == _playbackSpeed)
                                          const Spacer(),
                                        if (speed == _playbackSpeed)
                                          const Icon(
                                            Icons.check,
                                            color: Color(0xFF6C3CE1),
                                            size: 16,
                                          ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}