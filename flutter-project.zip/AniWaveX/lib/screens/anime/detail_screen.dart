// lib/screens/anime/detail_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:aniwavex/config/routes.dart';
import 'package:aniwavex/config/api.dart';
import 'package:aniwavex/config/constants.dart';
import 'package:aniwavex/models/anime.dart';
import 'package:aniwavex/services/anime_service.dart';
import 'package:aniwavex/services/storage_service.dart';
import 'package:aniwavex/utils/helpers.dart';

class AnimeDetailScreen extends ConsumerStatefulWidget {
  final String animeUrl;

  const AnimeDetailScreen({
    super.key,
    required this.animeUrl,
  });

  @override
  ConsumerState<AnimeDetailScreen> createState() => _AnimeDetailScreenState();
}

class _AnimeDetailScreenState extends ConsumerState<AnimeDetailScreen> {
  late Future<AnimeDetail> _detailFuture;
  bool _isFavorite = false;
  bool _isLoadingFavorite = false;
  String? _favoriteId;

  @override
  void initState() {
    super.initState();
    _detailFuture = AnimeService.getAnimeDetail(widget.animeUrl);
    _checkFavorite();
  }

  Future<void> _checkFavorite() async {
    try {
      final response = await ApiClient.get(AppConstants.endpointFavorites);
      if (response.statusCode == 200 && response.data['success']) {
        final favorites = response.data['data'] as List;
        final exists = favorites.any((f) => f['animeId'] == widget.animeUrl);
        if (exists) {
          final fav = favorites.firstWhere((f) => f['animeId'] == widget.animeUrl);
          setState(() {
            _isFavorite = true;
            _favoriteId = fav['id']?.toString();
          });
        }
      }
    } catch (e) {
      debugPrint('Error checking favorite: $e');
    }
  }

  Future<void> _toggleFavorite() async {
    setState(() => _isLoadingFavorite = true);

    try {
      if (_isFavorite && _favoriteId != null) {
        final response = await ApiClient.delete(
          '${AppConstants.endpointFavorites}/$_favoriteId',
        );
        if (response.statusCode == 200 && response.data['success']) {
          setState(() {
            _isFavorite = false;
            _favoriteId = null;
          });
          Helpers.showSnackBar(context, 'Removed from favorites');
        }
      } else {
        final response = await ApiClient.post(
          AppConstants.endpointFavorites,
          data: {
            'animeId': widget.animeUrl,
            'title': 'Anime',
            'imageUrl': '',
          },
        );
        if (response.statusCode == 200 && response.data['success']) {
          setState(() {
            _isFavorite = true;
            _favoriteId = response.data['id']?.toString();
          });
          Helpers.showSnackBar(context, 'Added to favorites');
        }
      }
    } catch (e) {
      Helpers.showSnackBar(
        context,
        'Failed to toggle favorite: $e',
        isError: true,
      );
    } finally {
      setState(() => _isLoadingFavorite = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<AnimeDetail>(
        future: _detailFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.error_outline,
                    size: 64,
                    color: Colors.red,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Failed to load anime details',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _detailFuture = AnimeService.getAnimeDetail(widget.animeUrl);
                      });
                    },
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          final detail = snapshot.data!;
          return CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 350,
                pinned: true,
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      CachedNetworkImage(
                        imageUrl: detail.info.imageUrl,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Container(
                          color: Colors.grey.shade800,
                        ),
                        errorWidget: (context, url, error) => Container(
                          color: Colors.grey.shade800,
                          child: const Icon(
                            Icons.image_not_supported,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.7),
                            ],
                            stops: const [0.5, 1.0],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 16,
                        left: 16,
                        right: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              detail.info.title,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            if (detail.info.japaneseTitle.isNotEmpty) ...[
                              const SizedBox(height: 4),
                              Text(
                                detail.info.japaneseTitle,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.7),
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                actions: [
                  IconButton(
                    icon: Icon(
                      _isFavorite ? Icons.favorite : Icons.favorite_border,
                      color: _isFavorite ? Colors.red : Colors.white,
                    ),
                    onPressed: _isLoadingFavorite ? null : _toggleFavorite,
                  ),
                  IconButton(
                    icon: const Icon(Icons.share, color: Colors.white),
                    onPressed: () {
                      // Share functionality
                    },
                  ),
                ],
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildInfoGrid(detail.info),
                      const SizedBox(height: 16),
                      if (detail.info.synopsis.isNotEmpty) ...[
                        const Text(
                          'Synopsis',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          detail.info.synopsis,
                          style: TextStyle(
                            fontSize: 14,
                            height: 1.6,
                            color: Colors.grey.shade700,
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                      const Text(
                        'Episodes',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      _buildEpisodeList(detail.episodes, detail.info.title),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildInfoGrid(AnimeInfo info) {
    final items = [
      ['Score', info.score],
      ['Type', info.type],
      ['Status', info.status],
      ['Total', info.totalEpisodes],
      ['Studio', info.studio],
      ['Genres', info.genres],
    ];

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.all(12),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 2.5,
          mainAxisSpacing: 4,
          crossAxisSpacing: 4,
        ),
        itemCount: items.length,
        itemBuilder: (context, index) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                items[index][0],
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.grey.shade500,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                items[index][1],
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildEpisodeList(List<Episode> episodes, String animeTitle) {
    if (episodes.isEmpty) {
      return const Text(
        'No episodes available',
        style: TextStyle(
          color: Colors.grey,
        ),
      );
    }

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: episodes.length,
      itemBuilder: (context, index) {
        final episode = episodes[index];
        final progress = StorageService.getWatchProgress(
          widget.animeUrl,
          episode.link,
        );

        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: progress != null && progress > 80
                    ? Colors.green
                    : progress != null && progress > 0
                    ? Colors.orange
                    : Theme.of(context).primaryColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  '${index + 1}',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: progress != null && progress > 80
                        ? Colors.white
                        : Theme.of(context).primaryColor,
                  ),
                ),
              ),
            ),
            title: Text(
              episode.title,
              style: const TextStyle(
                fontWeight: FontWeight.w500,
              ),
            ),
            subtitle: episode.date.isNotEmpty
                ? Text(
                    episode.date,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                    ),
                  )
                : null,
            trailing: progress != null && progress > 0
                ? Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: progress > 80 ? Colors.green : Colors.orange,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '${progress}%',
                      style: const TextStyle(
                        fontSize: 10,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  )
                : const Icon(
                    Icons.play_circle_outline,
                    color: Color(0xFF6C3CE1),
                  ),
            onTap: () async {
              try {
                final streamingData = await AnimeService.getStreamingUrl(
                  episode.link,
                );
                if (!mounted) return;
                Navigator.pushNamed(
                  context,
                  AppRoutes.player,
                  arguments: {
                    'videoUrl': streamingData.videoUrl,
                    'animeTitle': animeTitle,
                    'episodeTitle': episode.title,
                    'episodeUrl': episode.link,
                  },
                );
              } catch (e) {
                if (!mounted) return;
                Helpers.showSnackBar(
                  context,
                  'Failed to load video: $e',
                  isError: true,
                );
              }
            },
          ),
        );
      },
    );
  }
}