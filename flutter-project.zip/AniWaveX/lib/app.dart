// lib/app.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:aniwavex/config/routes.dart';
import 'package:aniwavex/config/themes.dart';
import 'package:aniwavex/providers/theme_provider.dart';
import 'package:aniwavex/screens/splash/splash_screen.dart';

class AniWaveXApp extends ConsumerWidget {
  const AniWaveXApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);
    
    return MaterialApp(
      title: 'AniWaveX',
      theme: AppThemes.lightTheme,
      darkTheme: AppThemes.darkTheme,
      themeMode: themeMode,
      debugShowCheckedModeBanner: false,
      onGenerateRoute: AppRoutes.generateRoute,
      initialRoute: '/splash',
      home: const SplashScreen(),
    );
  }
}