// lib/services/storage_service.dart
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:aniwavex/models/user.dart';

class StorageService {
  static late FlutterSecureStorage _secureStorage;
  static late SharedPreferences _preferences;

  static Future<void> init(FlutterSecureStorage secureStorage) async {
    _secureStorage = secureStorage;
    _preferences = await SharedPreferences.getInstance();
  }

  // Token
  static Future<void> saveToken(String token) async {
    await _secureStorage.write(key: 'auth_token', value: token);
  }

  static Future<String?> getToken() async {
    return await _secureStorage.read(key: 'auth_token');
  }

  static Future<void> clearToken() async {
    await _secureStorage.delete(key: 'auth_token');
  }

  // User
  static Future<void> saveUser(User user) async {
    await _preferences.setString('user', jsonEncode(user.toJson()));
  }

  static User? getUser() {
    final userJson = _preferences.getString('user');
    if (userJson == null) return null;
    try {
      return User.fromJson(jsonDecode(userJson));
    } catch (e) {
      return null;
    }
  }

  static Future<void> clearUser() async {
    await _preferences.remove('user');
  }

  // Settings
  static Future<void> saveString(String key, String value) async {
    await _preferences.setString(key, value);
  }

  static String? getString(String key) {
    return _preferences.getString(key);
  }

  static Future<void> saveBool(String key, bool value) async {
    await _preferences.setBool(key, value);
  }

  static bool? getBool(String key) {
    return _preferences.getBool(key);
  }

  static Future<void> saveInt(String key, int value) async {
    await _preferences.setInt(key, value);
  }

  static int? getInt(String key) {
    return _preferences.getInt(key);
  }

  // Cache
  static Future<void> saveCache(String key, String value) async {
    await _preferences.setString('cache_$key', value);
  }

  static String? getCache(String key) {
    return _preferences.getString('cache_$key');
  }

  static Future<void> clearCache() async {
    final keys = _preferences.getKeys();
    for (final key in keys) {
      if (key.startsWith('cache_')) {
        await _preferences.remove(key);
      }
    }
  }

  // Clear all
  static Future<void> clearAll() async {
    await _secureStorage.deleteAll();
    await _preferences.clear();
  }

  // Watch progress
  static Future<void> saveWatchProgress(String animeId, String episodeId, int progress) async {
    final key = 'watch_progress_${animeId}_$episodeId';
    await _preferences.setInt(key, progress);
  }

  static int? getWatchProgress(String animeId, String episodeId) {
    final key = 'watch_progress_${animeId}_$episodeId';
    return _preferences.getInt(key);
  }

  static Future<void> clearWatchProgress() async {
    final keys = _preferences.getKeys();
    for (final key in keys) {
      if (key.startsWith('watch_progress_')) {
        await _preferences.remove(key);
      }
    }
  }
}