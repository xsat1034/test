// lib/services/auth_service.dart
import 'package:dio/dio.dart';
import 'package:aniwavex/config/api.dart';
import 'package:aniwavex/config/constants.dart';
import 'package:aniwavex/models/user.dart';
import 'package:aniwavex/services/storage_service.dart';

class AuthService {
  static Future<Map<String, dynamic>> login(
      String username,
      String password,
      ) async {
    try {
      final response = await ApiClient.post(
        AppConstants.endpointLogin,
        data: {
          'username': username.trim(),
          'password': password,
        },
      );

      final data = response.data;

      if (response.statusCode == 200 && data['success'] == true) {
        final user = User.fromJson(data['user']);

        await StorageService.saveToken(data['token']);
        await StorageService.saveUser(user);

        return {
          'success': true,
          'user': user,
        };
      }

      return {
        'success': false,
        'error': data['error'] ??
            data['message'] ??
            'Login failed',
      };
    } on DioException catch (e) {
      final response = e.response;

      return {
        'success': false,
        'error': response?.data?['error'] ??
            response?.data?['message'] ??
            e.message ??
            e.toString(),
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  static Future<Map<String, dynamic>> register(
      String username,
      String email,
      String password,
      ) async {
    try {
      final response = await ApiClient.post(
        AppConstants.endpointRegister,
        data: {
          'username': username.trim(),
          'email': email.trim().toLowerCase(),
          'password': password,
        },
      );

      final data = response.data;

      if ((response.statusCode == 200 ||
              response.statusCode == 201) &&
          data['success'] == true) {
        final user = User.fromJson(data['user']);

        await StorageService.saveToken(data['token']);
        await StorageService.saveUser(user);

        return {
          'success': true,
          'user': user,
        };
      }

      return {
        'success': false,
        'error': data['error'] ??
            data['message'] ??
            'Registration failed',
      };
    } on DioException catch (e) {
      final response = e.response;

      return {
        'success': false,
        'error': response?.data?['error'] ??
            response?.data?['message'] ??
            e.message ??
            e.toString(),
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  static Future<Map<String, dynamic>> logout() async {
    try {
      await ApiClient.post(AppConstants.endpointLogout);
    } catch (_) {}

    await StorageService.clearAll();

    return {
      'success': true,
    };
  }

  static Future<Map<String, dynamic>> resetPassword(String email) async {
    try {
      final response = await ApiClient.post(
        AppConstants.endpointResetPassword,
        data: {
          'email': email.trim(),
        },
      );

      final data = response.data;

      return {
        'success': data['success'] ?? false,
        'message': data['message'] ??
            data['error'] ??
            '',
      };
    } on DioException catch (e) {
      return {
        'success': false,
        'error': e.response?.data?['error'] ??
            e.response?.data?['message'] ??
            e.message ??
            e.toString(),
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  static Future<bool> isLoggedIn() async {
    final token = await StorageService.getToken();

    if (token == null) return false;

    try {
      final response =
          await ApiClient.get(AppConstants.endpointValidate);

      return response.statusCode == 200 &&
          response.data['valid'] == true;
    } catch (_) {
      return false;
    }
  }

  static Future<User?> getCurrentUser() async {
    final cached = StorageService.getUser();

    if (cached == null) return null;

    try {
      final response =
          await ApiClient.get(AppConstants.endpointProfile);

      if (response.statusCode == 200 &&
          response.data['success'] == true) {
        final user = User.fromJson(response.data['user']);

        await StorageService.saveUser(user);

        return user;
      }

      return cached;
    } catch (_) {
      return cached;
    }
  }

  static Future<Map<String, dynamic>> updateProfile({
    String? displayName,
    String? email,
    String? phone,
    String? avatar,
  }) async {
    try {
      final response = await ApiClient.put(
        AppConstants.endpointProfile,
        data: {
          if (displayName != null) 'displayName': displayName,
          if (email != null) 'email': email,
          if (phone != null) 'phone': phone,
          if (avatar != null) 'avatar': avatar,
        },
      );

      final data = response.data;

      if (response.statusCode == 200 &&
          data['success'] == true) {
        final user = User.fromJson(data['user']);

        await StorageService.saveUser(user);

        return {
          'success': true,
          'user': user,
        };
      }

      return {
        'success': false,
        'error': data['error'] ??
            data['message'] ??
            'Failed to update profile',
      };
    } on DioException catch (e) {
      return {
        'success': false,
        'error': e.response?.data?['error'] ??
            e.response?.data?['message'] ??
            e.message ??
            e.toString(),
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }
}