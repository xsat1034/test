// lib/services/anime_service.dart
import 'package:dio/dio.dart';
import 'package:aniwavex/config/api.dart';
import 'package:aniwavex/config/constants.dart';
import 'package:aniwavex/models/anime.dart';

class AnimeService {
  static Future<List<Anime>> getOngoingAnime() async {
    try {
      final response = await ApiClient.get(AppConstants.endpointOngoing);
      
      if (response.statusCode == 200 && response.data['status']) {
        final data = response.data['data'] as List;
        return data.map((json) => Anime.fromJson(json)).toList();
      }
      return [];
    } on DioException catch (e) {
      throw Exception('Failed to load ongoing anime: ${e.message}');
    } catch (e) {
      throw Exception('Failed to load ongoing anime: $e');
    }
  }

  static Future<List<Anime>> searchAnime(String query) async {
    try {
      final response = await ApiClient.get(
        AppConstants.endpointSearch,
        queryParams: {'q': query},
      );
      
      if (response.statusCode == 200 && response.data['status']) {
        final data = response.data['data'] as List;
        return data.map((json) => Anime.fromJson(json)).toList();
      }
      return [];
    } on DioException catch (e) {
      throw Exception('Failed to search anime: ${e.message}');
    } catch (e) {
      throw Exception('Failed to search anime: $e');
    }
  }

  static Future<AnimeDetail> getAnimeDetail(String url) async {
    try {
      final response = await ApiClient.get(
        AppConstants.endpointDetail,
        queryParams: {'url': url},
      );
      
      if (response.statusCode == 200 && response.data['status']) {
        return AnimeDetail.fromJson(response.data['data']);
      }
      throw Exception('Failed to load anime detail');
    } on DioException catch (e) {
      throw Exception('Failed to load anime detail: ${e.message}');
    } catch (e) {
      throw Exception('Failed to load anime detail: $e');
    }
  }

  static Future<StreamingData> getStreamingUrl(String url) async {
    try {
      final response = await ApiClient.get(
        AppConstants.endpointWatch,
        queryParams: {'url': url},
      );
      
      if (response.statusCode == 200 && response.data['status']) {
        return StreamingData.fromJson(response.data['data']);
      }
      throw Exception('Failed to get streaming URL');
    } on DioException catch (e) {
      throw Exception('Failed to get streaming URL: ${e.message}');
    } catch (e) {
      throw Exception('Failed to get streaming URL: $e');
    }
  }

  static Future<List<Anime>> getTrendingAnime() async {
    try {
      final response = await ApiClient.get(AppConstants.endpointTrending);
      
      if (response.statusCode == 200 && response.data['status']) {
        final data = response.data['data'] as List;
        return data.map((json) => Anime.fromJson(json)).toList();
      }
      return [];
    } on DioException catch (e) {
      throw Exception('Failed to load trending anime: ${e.message}');
    } catch (e) {
      throw Exception('Failed to load trending anime: $e');
    }
  }

  static Future<List<Anime>> getLatestEpisodes() async {
    try {
      final response = await ApiClient.get(AppConstants.endpointLatest);
      
      if (response.statusCode == 200 && response.data['status']) {
        final data = response.data['data'] as List;
        return data.map((json) => Anime.fromJson(json)).toList();
      }
      return [];
    } on DioException catch (e) {
      throw Exception('Failed to load latest episodes: ${e.message}');
    } catch (e) {
      throw Exception('Failed to load latest episodes: $e');
    }
  }

  static Future<List<Anime>> getRecommendations() async {
    try {
      // Use trending as recommendations for now
      return await getTrendingAnime();
    } catch (e) {
      return [];
    }
  }

  static Future<Map<String, dynamic>> getGenres() async {
    try {
      final response = await ApiClient.get('/api/anime/genres');
      
      if (response.statusCode == 200 && response.data['status']) {
        return response.data['data'];
      }
      return {};
    } catch (e) {
      return {};
    }
  }

  static Future<Map<String, dynamic>> getSchedule() async {
    try {
      final response = await ApiClient.get('/api/anime/schedule');
      
      if (response.statusCode == 200 && response.data['status']) {
        return response.data['data'];
      }
      return {};
    } catch (e) {
      return {};
    }
  }
}